package lock;

import org.eclipse.paho.client.mqttv3.*;

import com.google.gson.Gson;
import com.phidget22.*;

import mqtt.utils.Utils;
//import lock.RFIDData;

public class SubscriberCallback implements MqttCallback {

	public static final String userid = "17065901";
	
	Gson gson = new Gson();

	String rfiddataJson = new String();
	RFIDData rfiddata = new RFIDData("unknown", 17065901);

	@Override
	public void connectionLost(Throwable cause) {
		System.out.println("\n" + cause);
	}

	@Override
	public void messageArrived(String topic, MqttMessage message) throws PhidgetException, MqttException {
		System.out.println("\nCredentials received from MQTT broker.");
		String responseFromServer = Validation.validateRFID(message.toString());
		System.out.println("\n");
		
		if (!responseFromServer.equals("Incorrect")) {
			System.out.println("trying to open door");
			rfiddata = gson.fromJson(responseFromServer, RFIDData.class);
			rfiddata.setValid(true);
			openDoor(rfiddata.getTagId(), rfiddata.getReaderId(), rfiddata.getValid(), rfiddata.getDoorId());
		}else {
			System.out.println("Not authorised to open this door");
			rfiddata = gson.fromJson(message.toString(), RFIDData.class);
			rfiddata.setValid(false);
			lock.Publisher.publish(rfiddata);
		}

		if ((userid + "/LWT").equals(topic)) {
			System.err.println("Sensor lost");
		}
	}

	private void openDoor(String tagid, int readerid, Boolean valid, int doorid) throws PhidgetException, MqttException {
		System.out.println("\nOpening door\n");
		LockMover.moveServoTo(180);

		
		System.out.println("Publishing door status");
		rfiddata.setTagId(tagid);
		rfiddata.setReaderId(readerid);
		rfiddata.setValid(valid);
		rfiddata.setDoorId(doorid);
	
		Publisher.publish(rfiddata);

		System.out.println("Saving operation to database");
		sendToServer(rfiddata);
		Utils.waitFor(3);
		System.out.println("Door open");
		LockMover.moveServoTo(0);
		Utils.waitFor(1);
		System.out.println("Door closed");
	}

	private void sendToServer(RFIDData rfid) {
		rfiddataJson = gson.toJson(rfid.toString());
		RFIDDataToServer.sendDataToServer(rfiddataJson);
	}

	@Override
	public void deliveryComplete(IMqttDeliveryToken arg0) {
		// TODO Auto-generated method stub
		
	}
}

