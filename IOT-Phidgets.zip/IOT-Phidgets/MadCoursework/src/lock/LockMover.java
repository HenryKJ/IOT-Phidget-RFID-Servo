package lock;

import com.phidget22.*;



public class LockMover {

	static RCServo ch = null;

	public static RCServo getInstance() {
		if (ch == null) {
			ch = LockMove();
		}
		return ch;
	}

	private static RCServo LockMove() {
		try {
			System.out.println("Constructing LockMover");
			
			ch = new RCServo();
			ch.addTargetPositionReachedListener(new RCServoTargetPositionReachedListener() {
				public void onTargetPositionReached(RCServoTargetPositionReachedEvent e) {
					System.out.println("Target Position Reached: " + e.getPosition());
				}
			});
			
			ch.open(2000);
			
		} catch (PhidgetException e) {
			e.getMessage();
		}
		return ch;
	}

	public static void moveServoTo(double motorPos) throws PhidgetException {
		LockMover.getInstance();
		ch.setMaxPosition(210.0);
		ch.setTargetPosition(motorPos);
		System.out.println("Moving motor to " + motorPos);
		ch.setEngaged(true);
	}

}
