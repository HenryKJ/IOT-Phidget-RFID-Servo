package lock;

import java.io.*;
import java.net.*;

public class RFIDDataToServer {
	
	public static String ServerURL = "http://localhost:8080/MadCourseworkServer/ServerDB";

	public static String sendDataToServer(String RFIDJson) {
		
		URL url;
		HttpURLConnection conn;
		BufferedReader br;
		
		try {
			RFIDJson = URLEncoder.encode(RFIDJson, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		
		String FullServerURL = ServerURL + "?setRFIDAttempts=" + RFIDJson;
		String blank;
		String result = "";
		
		try {
			url = new URL(FullServerURL);
			conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

			while ((blank = br.readLine()) != null) {
				result += blank;
			}
			br.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		return result;
		
	}

	public static String checkDataOnServer(String RFIDData) {
		System.out.println("Checking if data on server");
		URL url;
		HttpURLConnection conn;
		BufferedReader br;
		
		try {
			RFIDData = URLEncoder.encode(RFIDData, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		String fullServerURL = ServerURL + "?getRFIDServoData=" + RFIDData;
		System.out.println("Checking data with Server...");
		String blank;
		String result = "";
		try {
			url = new URL(fullServerURL);
			conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			
			while ((blank = br.readLine()) != null) {
				result += blank;
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
}
