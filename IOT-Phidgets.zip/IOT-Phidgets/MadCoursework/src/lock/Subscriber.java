package lock;

import org.eclipse.paho.client.mqttv3.*;

public class Subscriber {

	public static final String BROKER_URL = "tcp://mqtt.eclipse.org:1883";
	//public static final String BROKER_URL = "tcp://broker.mqttdashboard.com:1883";

	public static final String userid = "17065901";
	String clientId = userid + "-sub";

	public static MqttClient mqttClient;

	public Subscriber() {

		try {
			mqttClient = new MqttClient(BROKER_URL, clientId);
		} catch (MqttException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	public void start() {
		try {
			mqttClient.setCallback(new SubscriberCallback());
			if (!mqttClient.isConnected()) {
				mqttClient.connect();
			}
			final String topic = userid + "/openRequest";
			mqttClient.subscribe(topic);
			System.out.println("Successfully subscribed to topic: " + topic);
			System.out.println(mqttClient.toString());
		} catch (MqttException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}
}