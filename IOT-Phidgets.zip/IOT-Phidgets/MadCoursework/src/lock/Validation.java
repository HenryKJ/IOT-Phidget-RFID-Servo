package lock;

import com.google.gson.Gson;
import com.phidget22.*;

public class Validation {
	
	static String validateRFID(String RFIDDataJson) throws PhidgetException {

		
		RFIDData rfidTag = new RFIDData("Unknown");
		RFIDData RFIDDataFromServer = new RFIDData("Unknown");
		Gson gson = new Gson();
		String RFIDJson;
		String returnString = new String();

		rfidTag = gson.fromJson(RFIDDataJson, RFIDData.class);
		RFIDJson = gson.toJson(rfidTag);
		String response = RFIDDataToServer.checkDataOnServer(RFIDJson);
		RFIDDataFromServer = gson.fromJson(response, RFIDData.class);
		
		
		String rfidTagId = rfidTag.getTagId();
		String rfidTagIdFromServer = RFIDDataFromServer.getTagId();
		int thisDoorID = rfidTag.getDoorId();
		int doorIdFromServer = RFIDDataFromServer.getDoorId();

		
		if (thisDoorID == doorIdFromServer) {
			rfidTag.setValid(true);
			rfidTag.setAttempt("Success opening: " + RFIDDataFromServer.getDoorId()); 
			returnString = gson.toJson(rfidTag);
			System.out.println("Credentials Validated." + "[" + rfidTagId + " " + thisDoorID + "]" + 
														  "["+ rfidTagIdFromServer + " " + doorIdFromServer + "]");

		} else {
			returnString = "Incorrect";
			rfidTag.setAttempt("Failed opening: " + RFIDDataFromServer.getDoorId()); 
			System.out.println("\nWrong Tag " + rfidTag.getTagId()
								+ " does not have permission to open door Id:" + thisDoorID);
			
		}
		
		RFIDJson = gson.toJson(rfidTag);
		RFIDDataToServer.sendDataToServer(RFIDJson);
		return returnString;
	}
}


