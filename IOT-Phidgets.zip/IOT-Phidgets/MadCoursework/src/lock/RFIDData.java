package lock;

public class RFIDData {
	String tagId;
	int readerId;
	Boolean valid;
	int doorId;
	String Attempt;

	public RFIDData(String tagid, int readerid, Boolean isValid, int doorid, String attempt) {
		super();
		this.tagId = tagid;
		this.readerId = readerid;
		this.valid = isValid;
		this.doorId = doorid;
		this.Attempt = attempt;
	}
	
	public RFIDData(String tagid) {
		super();
		this.tagId = tagid;
	}

	public RFIDData(String tagid, int readerid) {
		super();
		this.tagId = tagid;
		this.readerId = readerid;
	}

	public String getTagId() {
		return tagId;
	}

	public void setTagId(String tagid) {
		this.tagId = tagid;
	}

	public int getReaderId() {
		return readerId;
	}

	public void setReaderId(int tagid) {
		this.readerId = tagid;
	}

	public Boolean getValid() {
		return valid;
	}

	public void setValid(Boolean isValid) {
		this.valid = isValid;
	}

	public int getDoorId() {
		return doorId;
	}

	public void setDoorId(int doorid) {
		this.doorId = doorid;
	}
	
	public String getAttempt() {
		return Attempt;
	}
	
	public void setAttempt(String attempt) {
		this.Attempt = attempt;
	}

	@Override
	public String toString() {
		return "RFIDData [tagid=" + tagId + ", readerid=" + readerId + ", isValid=" + valid + ", doorid=" + doorId + ", attempt=" + Attempt + "]";
	}
}
