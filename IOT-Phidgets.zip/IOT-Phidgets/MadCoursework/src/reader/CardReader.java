package reader;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttTopic;

import com.google.gson.Gson;

import com.phidget22.*;


public class CardReader { 
	
	RFID rfid = new RFID();	
	RFIDData rfiddata = new RFIDData("unknown");
	
	Gson gson = new Gson();
	
	String rfiddataJson = new String();
	public static String sensorServerURL = "http://localhost:8080/";
	
	private MqttClient client;
	
	public static final String BROKER_URL = "tcp://mqtt.eclipse.org:1883";
	//public static final String BROKER_URL = "tcp://broker.hivemq.com:1883";
	public static final String userid = "17065901";
	
	public static final String TOPIC = userid + "/openRequest";
	
	public static int doorid = 1;
	public static int tagid = Integer.parseInt(userid);
	public static boolean valid = false;
	
			
	public static void main(String[] args) throws PhidgetException, MqttException {
		CardReader cardReader = new CardReader();
		cardReader.start();
	}
	
	public CardReader() throws PhidgetException {
		try {
			client = new MqttClient(BROKER_URL, userid);
			MqttConnectOptions options = new MqttConnectOptions();
			options.setCleanSession(true);
			options.setMaxInflight(1000);
			options.setAutomaticReconnect(true);
			options.setWill(client.getTopic(userid + "/LWT"), "Disconnected mqtt".getBytes(), 0, false);
			if (!client.isConnected()) {
				client.connect(options);
			}

		} catch (MqttException e) {
			e.printStackTrace();
			System.exit(1);
		}
		
		/**rfid.addTagListener(new RFIDTagListener() {
		
			public void onTag(RFIDTagEvent e) {
				String tagRead = e.getTag();
				
				System.out.println("DEBUG: Tag read: " + tagRead);
				
				rfiddata.setTagId(tagRead);
				rfiddata.setReaderId(userid);
				rfiddata.setDoorId(doorid);
				rfiddataJson = gson.toJson(rfiddata);
				
				try {
					publishTag(rfiddata);
				} catch (MqttException e1) {
					e1.printStackTrace();
				}			
				System.out.println("Tag published: " + tagRead);			
			}
		});
		
		rfid.addTagLostListener(new RFIDTagLostListener() {
			
			public void onTagLost(RFIDTagLostEvent e) {
				System.out.println("Tag lost: " + e.getTag());
			}
		});
		
		try {
			
			rfid.open(10000);
			rfid.setAntennaEnabled(true);
		
		} catch (PhidgetException ex) {
			System.out.println(ex.getDescription());
			rfid.close();
		}  CODE BELOW IS FOR TESTING **/
	}  
		
		void start() throws MqttException, PhidgetException {
			try {
				rfiddata.setReaderId(tagid);
				rfiddata.setTagId("yhman"); 
				rfiddata.setDoorId(doorid); 
				rfiddata.setValid(valid); 
				
					System.out.println("\nTag in!");
					Thread.sleep(500);
					System.out.println("Tag out!");
					publishTag(rfiddata);
				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	
	private void publishTag(RFIDData rfiddata) throws MqttException {
		final MqttTopic Topic = client.getTopic(TOPIC);
		rfiddataJson = gson.toJson(rfiddata);
		Topic.publish(new MqttMessage(rfiddataJson.getBytes()));
		System.out.println("Tag data published. Topic: " + Topic.getName());
	}
}