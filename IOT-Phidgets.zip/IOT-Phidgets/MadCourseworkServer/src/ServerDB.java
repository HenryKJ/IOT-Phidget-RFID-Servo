
import javax.servlet.ServletConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import java.util.*;
import java.io.*;
import java.sql.*;

/**
 * Servlet implementation class ServerDB
 */

@WebServlet("/ServerDB")
public class ServerDB extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	Gson gson = new Gson();
	
	Connection conn = null;
	Statement stmt;
	
    public ServerDB() {
        super();
    }
    
    public void destroy() {
		try {
			conn.close();
		} catch (SQLException se) {
			System.out.println(se);
		}
	} 
    
    public void init(ServletConfig config) throws ServletException {
    	
    	super.init(config);
    	String user = "kubikjh";
		String password = "Flenbdod2";
		
		String url = "jdbc:mysql://mudfoot.doc.stu.mmu.ac.uk:6306/" + user;

		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (Exception e) {
			System.out.println(e);
		}

		
		try {
			conn = DriverManager.getConnection(url, user, password);
			System.out.println("Sensor to DB  server is up and running\n");
			

			System.out.println("DEBUG: Connection to Server successful.");
			stmt = conn.createStatement();
		} catch (SQLException se) {
			System.out.println(se);
		}
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setStatus(HttpServletResponse.SC_OK);
		
		RFIDData rfiddata = new RFIDData("unknown");
		

		String getRFID = request.getParameter("getRFIDServoData");
		String setRFID = request.getParameter("setRFIDAttempts");
		try {
			init(); 
			
			if (setRFID == null) {
				if(getRFID != null) {
					rfiddata = gson.fromJson(getRFID, RFIDData.class);	
					String tagid = rfiddata.getTagId();
					String resultsJson = retrieveRFIDData(tagid);
					PrintWriter out = response.getWriter();
					resultsJson = resultsJson.replace("[", "").replace("]", "");
					out.println(resultsJson);
					System.out.println("Response sent back to client\n");
					out.close();
				}
			} else 
			{
				rfiddata = gson.fromJson(setRFID, RFIDData.class);	
				updateAttemptTable(rfiddata);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}
	//Updates attempts
	private void updateAttemptTable(RFIDData rfiddata) {
		try {
			String updateSQL = "insert into "
					+ "RFIDAttempts(tagid, readerid, valid, doorid, attempt, timeinserted) "
					+ "values('" + rfiddata.getTagId() + "','" + rfiddata.getReaderId() + "',"
					+ rfiddata.getValid() + ",'" + rfiddata.getDoorId() + "','" + rfiddata.getAttempt()
					+ "'," + "now());";

			System.out.println("DEBUG: Update: " + updateSQL);
			stmt.executeUpdate(updateSQL);
			System.out.println("DEBUG: Update successful ");
		} catch (SQLException se) {
			System.out.println(se);
			System.out.println("\nerror ");
			return;
		}
		return;
	}
	
	private String retrieveRFIDData(String tagid) {
		String selectSQL = "select * from RFIDServoData where tagid = '" + tagid + "';";
		ResultSet resultSet;

		ArrayList<RFIDData> allTags = new ArrayList<RFIDData>();
		System.out.println(selectSQL);
		System.out.println("\n");

		try {
			resultSet = stmt.executeQuery(selectSQL);
			
			RFIDData tagFromDatabase = new RFIDData("unknown"); 
			while (resultSet.next()) {
				tagFromDatabase.setTagId(resultSet.getString("tagid"));
				tagFromDatabase.setReaderId(resultSet.getInt("readerid"));
				tagFromDatabase.setValid(resultSet.getBoolean("valid"));
				tagFromDatabase.setDoorId(resultSet.getInt("doorid"));
				
				allTags.add(tagFromDatabase);
				
			}
		} catch (SQLException ex) {
			System.out.println("Error in SQL " + ex.getMessage());
		}
		String allTagsJson = gson.toJson(allTags);
		return allTagsJson;
	}

}
